<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2023 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

namespace Modules\ModuleExampleAmi\Setup;

use MikoPBX\Modules\Setup\PbxExtensionSetupBase;
use Modules\ModuleExampleAmi\Models\ModuleExampleAmi;

/**
 * Class PbxExtensionSetup
 * Module installer and uninstaller
 *
 * @package Modules\ModuleExampleAmi\Setup
 */
class PbxExtensionSetup extends PbxExtensionSetupBase
{
    /**
     * Install module database structure
     * WHY: Generate random AMI credentials during installation for security
     * WHEN: Called automatically during module installation
     *
     * @return bool Success status
     */
    public function installDB(): bool
    {
        // Call parent to create database structure
        if (!parent::installDB()) {
            return false;
        }

        // Find or create module settings record
        $settings = ModuleExampleAmi::findFirst();
        if ($settings === null) {
            $settings = new ModuleExampleAmi();
        }

        // WHY: Generate random AMI username with prefix for easy identification
        // FORMAT: ami_example_XXXXXXXX (8 random hex characters)
        $settings->ami_user = 'ami_example_' . substr(bin2hex(random_bytes(4)), 0, 8);

        // WHY: Generate secure random password
        // FORMAT: 32 random hex characters (16 bytes)
        $settings->ami_password = bin2hex(random_bytes(16));

        return $settings->save();
    }
}