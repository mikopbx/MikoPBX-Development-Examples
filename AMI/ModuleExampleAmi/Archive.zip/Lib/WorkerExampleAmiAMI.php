<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2023 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

namespace Modules\ModuleExampleAmi\Lib;

use MikoPBX\Common\Handlers\CriticalErrorsHandler;
use MikoPBX\Common\Providers\EventBusProvider;
use MikoPBX\Core\Asterisk\AsteriskManager;
use MikoPBX\Core\System\Util;
use MikoPBX\Core\Workers\WorkerBase;
use Phalcon\Di\Di;

require_once 'Globals.php';


/**
 * Worker class for AMI events listening
 * WHY: Listen to ALL Asterisk Manager Interface events and broadcast them to frontend
 * EDUCATIONAL: This demonstrates real-time event streaming from Asterisk to web browser
 */
class WorkerExampleAmiAMI extends WorkerBase
{
    protected AsteriskManager $am;

    /**
     * Start AMI events listener
     * WHY: Main entry point for worker process
     * FLOW: Connect to AMI → Listen for events → Broadcast to frontend via EventBus
     *
     * @param array $argv Command line arguments
     * @return void
     */
    public function start(array $argv): void
    {
        $this->am = Util::getAstManager();
        $this->setFilter();

        // WHY: Register callback for ALL AMI events (not just UserEvent)
        $this->am->addEventHandler("*", [$this, "callback"]);

        // WHY: Infinite loop to keep worker running
        while (true) {
            $result = $this->am->waitUserEvent(true);
            if ($result === []) {
                // WHY: Connection lost, need to reconnect
                usleep(100000);
                $this->am = Util::getAstManager();
                $this->setFilter();
            }
        }
    }

    /**
     * Setup AMI events filter
     * WHY: Configure which events to receive from Asterisk
     * EDUCATIONAL: We only filter for ping events, all other events pass through
     *
     * @return void
     */
    private function setFilter(): void
    {
        // WHY: Ping event to check worker is alive
        $pingTube = $this->makePingTubeName(self::class);
        $params   = ['Operation' => 'Add', 'Filter' => 'UserEvent: ' . $pingTube];
        $this->am->sendRequestTimeout('Filter', $params);

        // WHY: No additional filters - we want to see ALL events for educational purposes
        // NOTE: In production, filter only events you need to reduce network traffic
    }

    /**
     * AMI event callback processor
     * WHY: Process each AMI event and broadcast to frontend via EventBus
     * EDUCATIONAL: Shows how to use EventBusProvider for real-time frontend updates
     *
     * @param array $parameters Event parameters from Asterisk
     * @return void
     */
    public function callback(array $parameters): void
    {
        // WHY: Reply to ping requests to confirm worker is alive
        if ($this->replyOnPingRequest($parameters)) {
            return;
        }

        // WHY: Get DI container to access EventBusProvider
        $di = Di::getDefault();

        // WHY: Broadcast event to frontend via EventBus
        // CHANNEL: 'ami-events' - frontend JavaScript subscribes to this channel
        // FORMAT: {event, data, timestamp}
        $di->get(EventBusProvider::SERVICE_NAME)->publish('ami-events', [
            'event' => $parameters['Event'] ?? 'Unknown',
            'data' => $parameters,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }

}

// Start worker process
$workerClassname = WorkerExampleAmiAMI::class;
if (isset($argv) && count($argv) > 1) {
    cli_set_process_title($workerClassname);
    try {
        $worker = new $workerClassname();
        $worker->start($argv);
    } catch (\Throwable $e) {
        CriticalErrorsHandler::handleExceptionWithSyslog($e);
    }
}