<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2023 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

namespace Modules\ModuleExampleAmi\Lib;

use MikoPBX\Common\Models\PbxSettings;
use MikoPBX\Core\System\System;
use MikoPBX\Core\System\Util;
use MikoPBX\Core\Workers\Cron\WorkerSafeScriptsCore;
use MikoPBX\Modules\Config\ConfigClass;
use MikoPBX\PBXCoreREST\Lib\PBXApiResult;
use Modules\ModuleExampleAmi\Models\ModuleExampleAmi;

class ExampleAmiConf extends ConfigClass
{

    /**
     * Receive information about mikopbx main database changes
     *
     * @param mixed $data
     */
    public function modelsEventChangeData($data): void
    {
        // f.e. if somebody changes PBXLanguage, we will restart all workers
        if (
            $data['model'] === PbxSettings::class
            && $data['recordId'] === 'PBXLanguage'
        ) {
            $templateMain = new ExampleAmiMain();
            $templateMain->startAllServices(true);
        }
    }

    /**
     * Returns module workers to start at WorkerSafeScriptCore
     * WHY: Register worker processes that should be monitored and auto-restarted
     * EDUCATIONAL: Only one worker needed - AMI events listener
     *
     * @return array Worker configurations
     */
    public function getModuleWorkers(): array
    {
        return [
            [
                // WHY: CHECK_BY_AMI - worker connects to Asterisk AMI
                'type'   => WorkerSafeScriptsCore::CHECK_BY_AMI,
                'worker' => WorkerExampleAmiAMI::class,
            ],
        ];
    }

    /**
     * REST API callback handler (Pattern 1)
     * WHY: Simple REST API pattern for module endpoints
     * ENDPOINT: POST /pbxcore/api/modules/ModuleExampleAmi/{action}
     * EDUCATIONAL: Demonstrates moduleRestAPICallback pattern for simple API operations
     *
     * @param array $request Request data with 'action' and 'data' keys
     * @return PBXApiResult API response object
     */
    public function moduleRestAPICallback(array $request): PBXApiResult
    {
        $action = $request['action'] ?? '';
        $data   = $request['data'] ?? [];

        // WHY: match expression for clean routing (PHP 8.0+)
        return match ($action) {
            'sendCommand' => $this->sendAmiCommandAction($data),
            'check'       => $this->checkAction(),
            'reload'      => $this->reloadAction(),
            default       => $this->createErrorResult("Unknown action: {$action}")
        };
    }

    /**
     * Send AMI command to Asterisk
     * WHY: Execute arbitrary AMI commands for educational/debugging purposes
     * ENDPOINT: POST /pbxcore/api/modules/ModuleExampleAmi/sendCommand
     * EDUCATIONAL: Shows how to interact with Asterisk Manager Interface
     *
     * @param array $data Request data with 'command' key
     * @return PBXApiResult
     */
    private function sendAmiCommandAction(array $data): PBXApiResult
    {
        $res = new PBXApiResult();
        $res->processor = __METHOD__;

        $command = $data['command'] ?? '';

        if (empty($command)) {
            $res->success = false;
            $res->messages['error'] = ['Command is required'];
            return $res;
        }

        // WHY: Get Asterisk Manager connection
        $am = Util::getAstManager();

        // WHY: Send command to Asterisk and get response
        // FORMAT: Command action returns output as array
        $result = $am->sendRequestTimeout('Command', ['Command' => $command]);

        $res->success = true;
        $res->data = [
            'command' => $command,
            'response' => $result,
            'timestamp' => date('Y-m-d H:i:s')
        ];

        return $res;
    }

    /**
     * Check module status
     * WHY: Health check endpoint for monitoring
     * ENDPOINT: GET /pbxcore/api/modules/ModuleExampleAmi/check
     *
     * @return PBXApiResult
     */
    private function checkAction(): PBXApiResult
    {
        $templateMain = new ExampleAmiMain();
        return $templateMain->checkModuleWorkProperly();
    }

    /**
     * Reload module services
     * WHY: Restart workers without full module reload
     * ENDPOINT: POST /pbxcore/api/modules/ModuleExampleAmi/reload
     *
     * @return PBXApiResult
     */
    private function reloadAction(): PBXApiResult
    {
        $res = new PBXApiResult();
        $res->processor = __METHOD__;

        $templateMain = new ExampleAmiMain();
        $templateMain->startAllServices(true);

        $res->success = true;
        $res->data = ['message' => 'Services reloaded'];

        return $res;
    }

    /**
     * Create error result
     * WHY: Consistent error response format
     *
     * @param string $message Error message
     * @return PBXApiResult
     */
    private function createErrorResult(string $message): PBXApiResult
    {
        $res = new PBXApiResult();
        $res->processor = __METHOD__;
        $res->success = false;
        $res->messages['error'] = [$message];

        return $res;
    }


    /**
     * Generate manager.conf section for AMI access
     * WHY: Automatically configure Asterisk Manager Interface access for the module
     * WHEN: Called by Asterisk config generator when creating manager.conf
     *
     * @return string Configuration section for manager.conf
     */
    public function generateManagerConf(): string
    {
        // Get module settings with AMI credentials
        $settings = ModuleExampleAmi::findFirst();
        if ($settings === null) {
            return '';
        }

        // WHY: Generate AMI user section with secure permissions
        // FORMAT: Standard Asterisk manager.conf section format
        $conf = "[{$settings->ami_user}]" . PHP_EOL;
        $conf .= "secret={$settings->ami_password}" . PHP_EOL;

        // WHY: Security - deny all by default, then permit only localhost
        $conf .= 'deny=0.0.0.0/0.0.0.0' . PHP_EOL;
        $conf .= 'permit=127.0.0.1/255.255.255.255' . PHP_EOL;

        // WHY: Grant full read/write permissions for educational example
        // NOTE: In production, restrict to specific permissions needed
        $conf .= 'read=all' . PHP_EOL;
        $conf .= 'write=all' . PHP_EOL;
        $conf .= PHP_EOL;

        return $conf;
    }

    /**
     * Process after module enable
     * WHY: Reload Asterisk manager to apply new AMI user configuration
     * WHEN: Called automatically when module is enabled via web interface
     *
     * @return void
     */
    public function onAfterModuleEnable(): void
    {
        // WHY: Reload manager.conf to activate new AMI user
        System::invokeActions(['manager' => 0]);

        // Start module workers
        $templateMain = new ExampleAmiMain();
        $templateMain->startAllServices();
    }

    /**
     * Process after module disable
     * WHY: Reload Asterisk manager to remove AMI user configuration
     * WHEN: Called automatically when module is disabled via web interface
     *
     * @return void
     */
    public function onAfterModuleDisable(): void
    {
        // WHY: Reload manager.conf to remove AMI user
        System::invokeActions(['manager' => 0]);
    }
}