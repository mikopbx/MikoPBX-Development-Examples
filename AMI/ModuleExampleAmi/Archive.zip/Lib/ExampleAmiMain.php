<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2023 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

namespace Modules\ModuleExampleAmi\Lib;


use MikoPBX\Core\System\Processes;
use MikoPBX\Core\Workers\Cron\WorkerSafeScriptsCore;
use MikoPBX\Modules\PbxExtensionBase;
use MikoPBX\Modules\PbxExtensionUtils;
use MikoPBX\PBXCoreREST\Lib\PBXApiResult;

/**
 * Main module class for AMI Example
 * WHY: Handles module-level operations like health checks and worker management
 * EDUCATIONAL: Minimal implementation showing essential module functions
 */
class ExampleAmiMain extends PbxExtensionBase
{
    /**
     * Check module health
     * WHY: Health check endpoint for monitoring module status
     * ENDPOINT: Called via /pbxcore/api/modules/ModuleExampleAmi/check
     *
     * @return PBXApiResult Health check result
     */
    public function checkModuleWorkProperly(): PBXApiResult
    {
        $res = new PBXApiResult();
        $res->processor = __METHOD__;
        $res->success = true;
        $res->data = [
            'module' => 'ModuleExampleAmi',
            'status' => 'operational',
            'pattern' => 'AMI Events Streaming Example',
            'timestamp' => date('Y-m-d H:i:s')
        ];

        return $res;
    }

    /**
     * Start or restart module workers
     * WHY: Manage worker lifecycle (start/restart)
     * WHEN: Called on module enable or configuration changes
     * EDUCATIONAL: Shows how to control worker processes
     *
     * @param bool $restart If true, restart workers; if false, start only if not running
     * @return void
     */
    public function startAllServices(bool $restart = false): void
    {
        // WHY: Only start workers if module is enabled
        $moduleEnabled = PbxExtensionUtils::isEnabled($this->moduleUniqueId);
        if (!$moduleEnabled) {
            return;
        }

        // WHY: Get worker configurations from ConfigClass
        $configClass = new ExampleAmiConf();
        $workersToRestart = $configClass->getModuleWorkers();

        if ($restart) {
            // WHY: Force restart - kill existing and start new
            foreach ($workersToRestart as $moduleWorker) {
                Processes::processPHPWorker($moduleWorker['worker']);
            }
        } else {
            // WHY: Start only if not running - check health first
            $safeScript = new WorkerSafeScriptsCore();
            foreach ($workersToRestart as $moduleWorker) {
                if ($moduleWorker['type'] === WorkerSafeScriptsCore::CHECK_BY_AMI) {
                    $safeScript->checkWorkerAMI($moduleWorker['worker']);
                } else {
                    $safeScript->checkWorkerBeanstalk($moduleWorker['worker']);
                }
            }
        }
    }
}