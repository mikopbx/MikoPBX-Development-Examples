{# Tab menu #}
<div class="ui top attached tabular menu" id="ami-tab-menu">
    <a class="item active" data-tab="commands">{{ t._('module_ami_TabCommands') }}</a>
    <a class="item" data-tab="events">{{ t._('module_ami_TabEvents') }}</a>
</div>

{# Commands Tab #}
<div class="ui bottom attached tab segment active" data-tab="commands">
    <div class="ui segment">
        <h3 class="ui dividing header">
            <i class="code icon"></i>
            {{ t._('module_ami_SendCommand') }}
        </h3>

        <div class="ui form">
            <div class="field">
                <label>{{ t._('module_ami_CommandLabel') }}</label>
                <textarea id="ami-command-input" rows="3" placeholder="{{ t._('module_ami_CommandPlaceholder') }}"></textarea>
                <div class="ui pointing label">
                    <i class="info circle icon"></i>
                    {{ t._('module_ami_CommandHint') }}
                </div>
            </div>

            <button id="send-ami-command" class="ui primary button">
                <i class="paper plane icon"></i>
                {{ t._('module_ami_SendButton') }}
            </button>
            <button id="clear-response" class="ui button">
                <i class="eraser icon"></i>
                {{ t._('module_ami_ClearResponseButton') }}
            </button>
        </div>

        <div class="ui segment" style="margin-top: 1em;">
            <h4>{{ t._('module_ami_ResponseLabel') }}</h4>
            <div class="ui form">
                <div class="field">
                    <textarea id="ami-response-output" rows="12" readonly style="font-family: monospace; background-color: #f4f4f4;"></textarea>
                </div>
            </div>
        </div>
    </div>
</div>

{# Events Tab #}
<div class="ui bottom attached tab segment" data-tab="events">
    <div class="ui segment">
        <h3 class="ui dividing header">
            <i class="feed icon"></i>
            {{ t._('module_ami_EventsTitle') }}
        </h3>

        <div class="ui form">
            <div class="field">
                <div class="ui toggle checkbox" id="ami-events-toggle">
                    <input type="checkbox" checked>
                    <label>{{ t._('module_ami_EventsToggle') }}</label>
                </div>
            </div>
        </div>

        <div class="ui form" style="margin-top: 1em;">
            <div class="field">
                <label>
                    {{ t._('module_ami_EventsLogLabel') }}
                    <button id="clear-events" class="ui mini button" style="float: right;">
                        <i class="eraser icon"></i>
                        {{ t._('module_ami_ClearEventsButton') }}
                    </button>
                </label>
                <textarea id="ami-events-log" rows="20" readonly style="font-family: monospace; background-color: #272822; color: #f8f8f2;"></textarea>
                <div class="ui label">
                    <i class="info circle icon"></i>
                    {{ t._('module_ami_EventsHint') }}
                </div>
            </div>
        </div>
    </div>
</div>

{# Educational information #}
<div class="ui info message">
    <div class="header">
        <i class="graduation cap icon"></i>
        {{ t._('module_ami_EducationalHeader') }}
    </div>
    <ul class="list">
        <li>{{ t._('module_ami_EducationalInfo1') }}</li>
        <li>{{ t._('module_ami_EducationalInfo2') }}</li>
        <li>{{ t._('module_ami_EducationalInfo3') }}</li>
        <li>{{ t._('module_ami_EducationalInfo4') }}</li>
        <li>{{ t._('module_ami_EducationalInfo5') }}</li>
    </ul>
</div>
