<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2025 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

return [
    /**
     * Module metadata
     */
    'BreadcrumbModuleExampleAmi' => 'AMI Terminal Example',
    'SubHeaderModuleExampleAmi' => 'Educational module for Asterisk Manager Interface',

    /**
     * Tab Headers
     */
    'module_ami_TabCommands' => 'AMI Commands',
    'module_ami_TabEvents' => 'Real-time Events',

    /**
     * Command Section
     */
    'module_ami_SendCommand' => 'Send AMI Command',
    'module_ami_CommandLabel' => 'AMI Command (e.g., "core show channels", "sip show peers")',
    'module_ami_CommandPlaceholder' => 'Enter Asterisk Manager Interface command...',
    'module_ami_CommandHint' => 'Try commands like: core show version, sip show peers, pjsip show endpoints',
    'module_ami_SendButton' => 'Send Command',
    'module_ami_ClearResponseButton' => 'Clear Response',
    'module_ami_ResponseLabel' => 'Response:',

    /**
     * Events Section
     */
    'module_ami_EventsTitle' => 'Real-time AMI Events',
    'module_ami_EventsToggle' => 'Enable real-time events monitoring',
    'module_ami_EventsLogLabel' => 'Events Log',
    'module_ami_ClearEventsButton' => 'Clear Log',
    'module_ami_EventsHint' => 'Events are received in real-time via WebSocket EventBus',

    /**
     * Educational Info
     */
    'module_ami_EducationalHeader' => 'Educational Module',
    'module_ami_EducationalInfo1' => 'This module demonstrates real-time AMI event streaming from Asterisk to browser',
    'module_ami_EducationalInfo2' => 'Events are broadcast via EventBusProvider using \'ami-events\' channel',
    'module_ami_EducationalInfo3' => 'Frontend subscribes via EventBus.subscribe(\'ami-events\', callback)',
    'module_ami_EducationalInfo4' => 'AMI commands are sent via REST API Pattern 1 (moduleRestAPICallback)',
    'module_ami_EducationalInfo5' => 'AMI credentials are auto-generated during module installation',

    /**
     * JavaScript Messages
     */
    'module_ami_ErrorNoCommand' => 'Please enter a command',
    'module_ami_SendingCommand' => 'Sending command...',
    'module_ami_UnknownError' => 'Unknown error',
    'module_ami_ErrorPrefix' => 'Error: ',
    'module_ami_NetworkError' => 'Network error - please check connection',
    'module_ami_EventsEnabled' => 'AMI events monitoring enabled',
    'module_ami_EventsDisabled' => 'AMI events monitoring disabled',
    'module_ami_Initialized' => 'ModuleExampleAmi initialized - listening for AMI events on EventBus channel "ami-events"',
];
