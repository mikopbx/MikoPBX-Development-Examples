<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2023 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

namespace Modules\ModuleExampleAmi\Models;

use MikoPBX\Modules\Models\ModulesModelsBase;

class ModuleExampleAmi extends ModulesModelsBase
{

    /**
     * @Primary
     * @Identity
     * @Column(type="integer", nullable=false)
     */
    public $id;

    /**
     * AMI user name
     * WHY: Generated automatically during installation for secure AMI access
     *
     * @Column(type="string", nullable=true)
     */
    public $ami_user;

    /**
     * AMI password
     * WHY: Generated automatically during installation for secure AMI access
     *
     * @Column(type="string", nullable=true)
     */
    public $ami_password;

    /**
     * Initialize model
     * WHY: Set database table source
     *
     * @return void
     */
    public function initialize(): void
    {
        $this->setSource('m_ModuleExampleAmi');
        parent::initialize();
    }


}