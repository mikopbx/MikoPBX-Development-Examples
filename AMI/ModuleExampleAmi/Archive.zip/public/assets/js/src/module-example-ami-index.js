/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2025 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

/* global globalRootUrl, PbxApi, EventBus, $ */

/**
 * AMI Terminal Example Module
 * WHY: Educational module demonstrating AMI events streaming and command execution
 * ARCHITECTURE: EventBus subscription + REST API Pattern 1
 *
 * @module ModuleExampleAmi
 */
const ModuleExampleAmi = {
    /**
     * Events monitoring enabled flag
     * WHY: Toggle for event subscription
     */
    eventsEnabled: true,

    /**
     * Maximum lines in events log
     * WHY: Prevent memory overflow from unlimited events
     */
    maxEventsLogLines: 200,

    /**
     * Initialize module
     * WHY: Entry point - setup event handlers and EventBus subscription
     * EDUCATIONAL: Shows complete initialization pattern
     */
    initialize() {
        // WHY: Initialize Fomantic UI tabs
        $('#ami-tab-menu .item').tab();

        // WHY: Initialize Fomantic UI components
        ModuleExampleAmi.initializeUI();

        // WHY: Setup button handlers
        ModuleExampleAmi.setupEventHandlers();

        // WHY: Subscribe to AMI events via EventBus
        // CRITICAL: EventBus is the ONLY way to receive real-time events
        // Backend publishes to 'ami-events' channel via EventBusProvider
        EventBus.subscribe('ami-events', (data) => {
            ModuleExampleAmi.onAmiEvent(data);
        });

        console.log(globalTranslate.module_ami_Initialized);
    },

    /**
     * Initialize Fomantic UI components
     * WHY: Setup UI controls (checkboxes, etc.)
     */
    initializeUI() {
        // WHY: Initialize toggle checkbox for events monitoring
        $('#ami-events-toggle').checkbox({
            onChecked() {
                ModuleExampleAmi.eventsEnabled = true;
                console.log(globalTranslate.module_ami_EventsEnabled);
            },
            onUnchecked() {
                ModuleExampleAmi.eventsEnabled = false;
                console.log(globalTranslate.module_ami_EventsDisabled);
            }
        });
    },

    /**
     * Setup event handlers for buttons
     * WHY: Attach click handlers to UI controls
     */
    setupEventHandlers() {
        // WHY: Send AMI command button
        $('#send-ami-command').on('click', () => {
            ModuleExampleAmi.sendCommand();
        });

        // WHY: Allow Enter key in textarea to send command (with Ctrl/Cmd)
        $('#ami-command-input').on('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                ModuleExampleAmi.sendCommand();
            }
        });

        // WHY: Clear response button
        $('#clear-response').on('click', () => {
            $('#ami-response-output').val('');
        });

        // WHY: Clear events log button
        $('#clear-events').on('click', () => {
            $('#ami-events-log').val('');
        });
    },

    /**
     * Send AMI command to Asterisk
     * WHY: Execute AMI command via REST API and display response
     * ENDPOINT: POST /pbxcore/api/modules/ModuleExampleAmi/sendCommand
     * PATTERN: REST API Pattern 1 (moduleRestAPICallback)
     */
    sendCommand() {
        const command = $('#ami-command-input').val().trim();

        if (!command) {
            ModuleExampleAmi.showError(globalTranslate.module_ami_ErrorNoCommand);
            return;
        }

        // WHY: Show loading state
        $('#send-ami-command').addClass('loading');
        $('#ami-response-output').val(`${globalTranslate.module_ami_SendingCommand}\n`);

        // WHY: Make API request using Fomantic UI $.api
        $.api({
            url: `${globalRootUrl}pbxcore/api/modules/ModuleExampleAmi/sendCommand`,
            on: 'now',
            method: 'POST',
            data: { command },
            successTest: PbxApi.successTest,

            /**
             * Success callback
             * WHY: Handle successful API response
             */
            onSuccess(response) {
                $('#send-ami-command').removeClass('loading');

                // WHY: Format response for display
                const output = ModuleExampleAmi.formatCommandResponse(response);
                $('#ami-response-output').val(output);
            },

            /**
             * Failure callback
             * WHY: Handle API errors
             */
            onFailure(response) {
                $('#send-ami-command').removeClass('loading');

                const errorMsg = response.messages?.error?.join('\n') || globalTranslate.module_ami_UnknownError;
                $('#ami-response-output').val(`${globalTranslate.module_ami_ErrorPrefix}${errorMsg}`);
                ModuleExampleAmi.showError(errorMsg);
            },

            /**
             * Error callback
             * WHY: Handle network/HTTP errors
             */
            onError() {
                $('#send-ami-command').removeClass('loading');
                $('#ami-response-output').val(globalTranslate.module_ami_NetworkError);
            }
        });
    },

    /**
     * Format AMI command response for display
     * WHY: Convert API response to readable format
     *
     * @param {object} response - API response object
     * @returns {string} Formatted response text
     */
    formatCommandResponse(response) {
        const timestamp = response.data?.timestamp || new Date().toLocaleString();
        const command = response.data?.command || '';
        const result = response.data?.response || {};

        let output = `[${timestamp}] Command: ${command}\n`;
        output += '─'.repeat(80) + '\n';

        // WHY: Display response data
        if (result.data && Array.isArray(result.data)) {
            output += result.data.join('\n');
        } else if (typeof result === 'object') {
            output += JSON.stringify(result, null, 2);
        } else {
            output += result;
        }

        return output;
    },

    /**
     * Handle incoming AMI event from EventBus
     * WHY: Process real-time AMI events and display in log
     * EDUCATIONAL: Demonstrates EventBus.subscribe() callback pattern
     *
     * @param {object} data - Event data from EventBus
     * @param {string} data.event - Event type (e.g., "Newchannel", "Hangup")
     * @param {object} data.data - Full AMI event parameters
     * @param {string} data.timestamp - Event timestamp
     */
    onAmiEvent(data) {
        // WHY: Skip if events monitoring is disabled
        if (!ModuleExampleAmi.eventsEnabled) {
            return;
        }

        // WHY: Format event for display
        const eventLine = ModuleExampleAmi.formatEventLine(data);

        // WHY: Append to events log
        ModuleExampleAmi.appendToEventsLog(eventLine);
    },

    /**
     * Format AMI event as single log line
     * WHY: Create readable one-line format for event
     *
     * @param {object} data - Event data
     * @returns {string} Formatted event line
     */
    formatEventLine(data) {
        const timestamp = data.timestamp || new Date().toLocaleString();
        const event = data.event || 'Unknown';

        // WHY: Extract key event parameters for display
        const params = data.data || {};
        const keyParams = ModuleExampleAmi.extractKeyParams(params);

        return `[${timestamp}] ${event.padEnd(20)} ${keyParams}\n`;
    },

    /**
     * Extract key parameters from AMI event
     * WHY: Show most relevant info without overwhelming log
     *
     * @param {object} params - AMI event parameters
     * @returns {string} Key parameters string
     */
    extractKeyParams(params) {
        const keys = ['Channel', 'CallerIDNum', 'Exten', 'ConnectedLineNum', 'State', 'Cause'];
        const extracted = [];

        for (const key of keys) {
            if (params[key]) {
                extracted.push(`${key}=${params[key]}`);
            }
        }

        return extracted.join(', ');
    },

    /**
     * Append text to events log with line limit
     * WHY: Add event to log and prevent memory overflow
     *
     * @param {string} text - Text to append
     */
    appendToEventsLog(text) {
        const $log = $('#ami-events-log');
        let currentLog = $log.val();

        // WHY: Split into lines and limit to max lines
        let lines = currentLog.split('\n');
        lines.push(text.trim());

        if (lines.length > ModuleExampleAmi.maxEventsLogLines) {
            // WHY: Keep only recent lines
            lines = lines.slice(-ModuleExampleAmi.maxEventsLogLines);
        }

        $log.val(lines.join('\n'));

        // WHY: Auto-scroll to bottom to show latest events
        $log.scrollTop($log[0].scrollHeight);
    },

    /**
     * Show error message
     * WHY: User feedback for errors
     *
     * @param {string} message - Error message
     */
    showError(message) {
        // WHY: Use Fomantic UI toast for non-blocking notification
        if (typeof UserMessage !== 'undefined') {
            UserMessage.showError(message);
        } else {
            console.error(message);
        }
    }
};

/**
 * Initialize on document ready
 * WHY: Start module after DOM is loaded
 */
$(document).ready(() => {
    ModuleExampleAmi.initialize();
});
